ALTER TABLE scheduler.job
    ADD COLUMN job_action_type jobActionType;