DO
$$
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'jobActionType') THEN
            CREATE TYPE jobActionType AS ENUM ('HTTP', 'SLEEP', 'ECHO');
        END IF;
    END
$$ LANGUAGE plpgsql;
