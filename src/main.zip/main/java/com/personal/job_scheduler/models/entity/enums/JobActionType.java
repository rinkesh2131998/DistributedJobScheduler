package com.personal.job_scheduler.models.entity.enums;

public enum JobActionType {
    HTTP, SLEEP, ECHO
}
