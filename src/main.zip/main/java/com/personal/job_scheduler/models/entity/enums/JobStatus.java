package com.personal.job_scheduler.models.entity.enums;

public enum JobStatus {
    SCHEDULED, RUNNING, SUCCESS, FAILED, CANCELLED
}
