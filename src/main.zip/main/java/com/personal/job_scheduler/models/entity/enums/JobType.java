package com.personal.job_scheduler.models.entity.enums;

public enum JobType {
    CRON, ONE_TIME, MANUAL
}
