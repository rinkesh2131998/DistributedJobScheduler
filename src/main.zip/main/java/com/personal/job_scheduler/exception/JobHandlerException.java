package com.personal.job_scheduler.exception;

public class JobHandlerException extends RuntimeException {
    public JobHandlerException(String message) {
        super(message);
    }
}
